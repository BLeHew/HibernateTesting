create procedure GetUsersAttachedToProject(IN ProjID int)
  begin
select u.id,u.username,u.email,u.pass_hash,u.priv_lvl from users u, user_proj_assigned upa
where u.id = upa.user_id and upa.proj_id = ProjID;
end;

